# AAA Paradigm
# 1. Create Test data (Arrange)
# 2. Call Methods (Action)
# 3. Assert the Expected and Observed. (Assert)