from Inheritance import CoralCard

class ManageCoralCard2:
    def __init__(self, card):
        self.card = CoralCard(card) # CoralCard is Tightly Coupled with ManageCoralCard2
        self.owner = card["owner"]

# What steps we will take if ManageCoralCard2 needs to be coupled ONLY with a Debit Card
# Code Change #1. Class - self.card = DebitCard(card)
# Code Change #2. Caller of the class = spoon feeding the raw data

class ManageCard:
    def __init__(self, credit_card, owner):
        self.card = credit_card
        # This is loose coupling.
        # When we create an object of ManageCard, it get an object either of CoralCard or GlobeTrotterCard
        self.owner = owner