from abc import ABC, abstractmethod


# The ABC enforces ALL methods are abstract making
# switch class an Interface. ABC has NO implementation/methods of its OWN.
class PartialAbstract:
    @abstractmethod
    def abstractMehod(self):
        pass

    def nonAbstractMethod(self):
        print("something")

class Switch(ABC):
    @abstractmethod
    def switch_on(self):
        pass

    @abstractmethod
    def switch_off(self):
        pass


class PlasticSwitch(Switch):
    def switch_on(self):
        print("Plastic Switch is on")

    def switch_off(self):
        print('Plastic Switch is off')

    def emergency_indicator(self):
        print('Emergency Indicator Toggle')


class WifiSwitch(Switch):

    def switch_on(self):
        print("Wifi Switch is on")

    def switch_off(self):
        print('Wifi Switch is off')

class PushButtonSwitch(Switch):

    def switch_on(self):
        print("PushButton Switch is on")

    def switch_off(self):
        print('PushButton Switch is off')

