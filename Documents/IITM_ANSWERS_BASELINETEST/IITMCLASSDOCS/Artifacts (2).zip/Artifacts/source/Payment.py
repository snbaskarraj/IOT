class CreditCardPayment:
    def payment(self, amount: int):
        print("Payment Done for ", amount)


class MobileWalletPayment:
    def payment(self, amount: int):
        print("Payment Done for ", amount)